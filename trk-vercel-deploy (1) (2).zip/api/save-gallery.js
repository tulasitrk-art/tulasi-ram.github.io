const https = require('https');
const JSONBIN_KEY = '$2a$10$bUOFVWCKHp1QW1b3bvnXuOTW4VCAtaD8N8CJyHFE6IELrBMtGSc8C';

function httpsReq(options, body) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(d) }); }
        catch (e) { resolve({ status: res.statusCode, body: d }); }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

export const config = { api: { bodyParser: { sizeLimit: '1mb' } } };

export default async function handler(req, res) {
  const hdrs = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };
  Object.entries(hdrs).forEach(([k,v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();

  if (req.method === 'POST') {
    try {
      const { urls } = req.body;
      if (!Array.isArray(urls) || !urls.length) throw new Error('No URLs');
      const payload = JSON.stringify({ urls });
      const result = await httpsReq({
        hostname: 'api.jsonbin.io', path: '/v3/b', method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Master-Key': JSONBIN_KEY,
          'X-Bin-Private': 'false',
          'X-Bin-Name': 'trk-gallery',
          'Content-Length': Buffer.byteLength(payload)
        }
      }, payload);
      if (result.status !== 200) throw new Error('Storage error: ' + result.status);
      return res.status(200).json({ id: result.body.metadata.id });
    } catch (e) {
      return res.status(500).json({ error: e.message });
    }
  }

  if (req.method === 'GET') {
    try {
      const id = req.query.id;
      if (!id) throw new Error('Missing id');
      const result = await httpsReq({
        hostname: 'api.jsonbin.io', path: '/v3/b/' + id + '/latest', method: 'GET',
        headers: { 'X-Master-Key': JSONBIN_KEY }
      });
      if (result.status !== 200) return res.status(404).json({ error: 'Not found' });
      return res.status(200).json({ urls: result.body.record.urls });
    } catch (e) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}
