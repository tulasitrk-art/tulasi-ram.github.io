const https = require('https');

export const config = {
  api: {
    bodyParser: {
      sizeLimit: '60mb',
    },
  },
};

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-filename');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const chunks = [];
    for await (const chunk of req) chunks.push(chunk);
    const body = Buffer.concat(chunks);
    const filename = decodeURIComponent(req.headers['x-filename'] || 'video.mp4');

    const url = await new Promise((resolve, reject) => {
      const options = {
        hostname: 'transfer.sh',
        path: '/' + encodeURIComponent(filename),
        method: 'PUT',
        headers: {
          'Content-Length': body.length,
          'Content-Type': req.headers['content-type'] || 'video/mp4',
          'Max-Days': '365',
        }
      };
      const request = https.request(options, (response) => {
        let data = '';
        response.on('data', chunk => data += chunk);
        response.on('end', () => {
          if (response.statusCode === 200 && data.trim().startsWith('http')) {
            resolve(data.trim());
          } else {
            reject(new Error('transfer.sh failed: ' + response.statusCode + ' ' + data.substring(0, 100)));
          }
        });
      });
      request.on('error', reject);
      request.write(body);
      request.end();
    });

    res.status(200).json({ url });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
